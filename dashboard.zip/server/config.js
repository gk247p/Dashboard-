import { createRequire } from "node:module";

const require = createRequire(import.meta.url);

let sharedSettings = null;
try {
  sharedSettings = require("../../source/settings");
} catch {
  sharedSettings = null;
}

const defaultSecret =
  process.env.NODE_ENV === "production"
    ? "build-nextauth-secret"
    : sharedSettings?.Client?.botSecret ||
      sharedSettings?.Client?.Token ||
      "local-pogyclient-secret";

export function getConfig() {
  return {
    nextAuthSecret: process.env.NEXTAUTH_SECRET || defaultSecret,
    discordClientId: process.env.DISCORD_CLIENT_ID || sharedSettings?.Client?.botId || "1338449560594419834",
    discordClientSecret: process.env.DISCORD_CLIENT_SECRET || sharedSettings?.Client?.botSecret || "FMSASCledk7dMxV5MzY-ure5Qj8nXtiD",
    discordBotToken: process.env.DISCORD_BOT_TOKEN || sharedSettings?.Client?.Token || "MTMzODQ0OTU2MDU5NDQxOTgzNA.GH650d.vRDPj8KUNXyDyr7QcqwoqtezIFe3yClt6PSbOc",
    mongoUri: process.env.MONGODB_URI || sharedSettings?.Database?.Uri || "mongodb+srv://CodeXmongodb:codexop@codexcluster.tebuglj.mongodb.net/?appName=CodeXCluster",
    botApiBaseUrl: process.env.BOT_API_BASE_URL || "http://localhost:3001"
  };
}
